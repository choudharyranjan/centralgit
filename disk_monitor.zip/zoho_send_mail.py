#!/usr/bin/python3
import configparser
import smtplib
from email.mime.text import MIMEText
from email.header import Header
from email.utils import formataddr
import os
import ssl
import sys

def read_config():
    cfg_file = "ve_monitor.cfg"
    global conf 

    config = configparser.ConfigParser()
    config.read(cfg_file)
    conf = {
            "sender_email" : config.get("default", "SENDER_EMAIL"),
            "sender_password" : config.get("default", "SENDER_PASSWORD"),
            "sender_host" : config.get("default", "SENDER_HOST"),
            "sender_port" : int(config.get("default", "SENDER_PORT")),
            "support_email" : config.get("default", "SUPPORT_EMAIL"),
        } 
        # Not used
        #"threshold_percentage" : float(config.get("default", "THRESHOLD_PERCENTAGE")),

def send_warning_email(userid, user_email, assigned_quota, disk_usage, threshold_percentage):
    # Create SSL/TLS context
    context = ssl.create_default_context()

    # Format disk usage and assigned quota values to show only 2-3 decimal points
    disk_usage_gb = round(disk_usage / (1024 ** 2), 3)
    assigned_quota_gb = round(assigned_quota / (1024 ** 2), 3)

    # Check if the used quota exceeds the threshold
    msg = MIMEText(f"""\

Subject: Disk Usage Alert

Your ({userid}) disk usage has exceeded threshold and reached {threshold_percentage}% of your assigned quota.

Current disk usage: {disk_usage_gb} GB
Assigned quota    : {assigned_quota_gb} GB

From:
IT Admin 
VLSI Expert

        """,

        'plain', 'utf-8')
    msg['Subject'] =  Header(f"Disk Usage for {userid} reached {threshold_percentage}%", 'utf-8')
    msg['From'] = conf["sender_email"]
    msg['To'] = user_email
    msg['Cc'] = conf["support_email"]

    # Create server object with SSL option
    server = smtplib.SMTP_SSL(conf["sender_host"], conf["sender_port"], context=context)

    # Perform operations via server
    server.login(conf["sender_email"], conf["sender_password"])
    server.sendmail(conf["sender_email"], user_email, msg.as_string())
    server.quit()

if __name__ == "__main__":
    # Get parameters from command line arguments
    if len(sys.argv) != 6:
        print(f"Usage: {sys.argv[0]} <userid> <user_email> <assigned_quota> <disk_usage> <threshold_percentage>")
        print(f"Args:{len(sys.argv)} args:{sys.argv} ")
        sys.exit(1)
    # Check command line arguments
    try:
        userid = str(sys.argv[1])
        user_email = str(sys.argv[2])
        assigned_quota = int(sys.argv[3])
        disk_usage = int(sys.argv[4])
        threshold_percentage = float(sys.argv[5])
    except ValueError:
        print("Error: Invalid argument types.")
        print(f"Usage: {sys.argv[0]} <userid> <user_email> <assigned_quota> <disk_usage> <threshold_percentage>")
        sys.exit(1)

    read_config()
    send_warning_email(userid, user_email, assigned_quota, disk_usage, threshold_percentage)
