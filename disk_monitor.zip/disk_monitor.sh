#!/bin/bash

# To monitor the disk space of user home directory on the basis of user
ALERT="90.000000%" #alert level 90 % of 2GB space 
#ADMIN="itsupport@vlsiexpert.in" # sysadmin email ID
#MAX=2024
supportid="itsupport@vlsiexpert.in"


machines="`cat disk_monitor.cfg | grep -E -v -e '^\s*#' `"

#folder_to_skip="'^ve_be_master|ve_fe|test|ravi|mahesh|common|aquota|lost|misc|vncuser|khelen|puneet|centos'"

i=1
for macrec in $machines
do
    machine=`echo $macrec | sed -e 's#:.*$##g' `
    folders=`echo $macrec | sed -e 's#^.*:##g' `
    for folder in `echo $folders | sed -e 's#,# #g' `
    do
	if [[ -z $machine || -z $folder ]] ; then
	    echo "Blank machine name or folder name in line $macrec "
	    continue
	fi
	#echo "Proecssing $folder for machine $machine "
	users=$(ssh $machine sudo ls -1 $folder | grep -vE '^ve_|test|ravi|mahesh|common|aquota|lost|misc|vncuser|khelen|puneet|centos')
	#echo " Got users $users"
	for user in $users
	do
        echo "Analyzing $user on $machine"
	     usage=$(ssh $machine sudo du -s $folder/$user | awk '{print $1}')
	     MAX=$(ssh $machine sudo quota -u $user | tail -n1 | awk '{print $4}') 
	     percent=`echo "scale=2; $usage / $MAX * 100" | bc`
	      if [[ "$percent" > "$ALERT" ]]
	      then 
		     # printf "Machine(%32s)  User(%20s)  Usage(%10s)  Max(%8s)      %f%%\n" $machine $user $usage $MAX  $percent 
		     email=$(echo $user | grep $user vlsi_userfile.csv | cut -d',' -f5)
		     #echo $email
             echo "FOUND ISSUE ${user} $email $MAX $usage $percent"
             # For debugging purpose
             ./zoho_send_mail.py "${user}($email)" $supportid $MAX $usage $percent
             # Finally enable below 
             #./zoho_send_mail.py ${user} $email $MAX $usage $percent

             #sleep 1
             if [[ $i > 4 ]] ; then 
                 echo "EXITING after finding FOUR ERROR cases and SENDING EMAILs " ; exit 0
                 exit 0
             fi
             i=$(( i + 1))

	     fi
            
	done
    done
done
exit 0

